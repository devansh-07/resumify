# resumify
A Python package which uses fpdf library to create Resumes.
